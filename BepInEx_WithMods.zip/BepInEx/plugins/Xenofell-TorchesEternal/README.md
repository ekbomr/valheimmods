# Torches Eternal

Torches and other fire sources that require fuel (campfire, hearth, etc) will burn infinitely when using Torches Eternal.

# Installation

1. Install BepInEx.
2. Extract the mod download into <Valheim>/BepInEx/plugins folder so the .dll is inside of the plugins folder.
3. BepInEx will load the plugin and all should work. Enjoy!
